# perfmatters

Hey, you downloaded the perfmatters poster! Go you. 🤘

If you're planning on printing this yourself, you’re in luck — It’ll look great as an A4 poster, but will also scale perfectly to fit A3, A2, A1 or even A0. (Set your printer to scale to fit, it’s been designed to fit, no matter how basic your printer might be, it should look great).

## Licence

While this poster is free for you to print at your own discretion, please note that it is licensed under Creative Commons Attribution-NonCommerial 4.0

http://creativecommons.org/licenses/by-nc/4.0/

If you do remix this poster, we’d 100% love to see it — drop an email to hello at calibreapp.com, we’ll send you some swag.
